var express = require("express");
var morgan = require("morgan");
var hbs = require("hbs");
//var userRoutes = require("./routes/userRoutes");
//var todoRoutes = require("./routes/todoRoutes");
var path = require("path");

var app = express();

// Setting the default template engine to handlebars
//app.set("views", path.join(__dirname, "templates"));
app.set("view engine", "hbs");

// This is the area where you have to register your partials folder
hbs.registerPartials(path.join(__dirname, "views", "partials"));

// const trustedDomains = [
//   "https://sundeepcharan.com",
//   // 'https://www.google.com',
//   "http://127.0.0.1:5500"
// ];

// Middlewares
// app.use(function(req, res, next) {
//   // To allow certain domains you use here
//   if (trustedDomains.includes(req.headers.origin)) {
//     res.header("Access-Control-Allow-Origin", req.headers.origin);
//   }
//   // To restrict the client to use only some headers, they are mentioned here.
//   res.header("Access-Control-Allow-Headers", "Content-Type");
//   next();
// });

app.use(express.static(path.join(__dirname, "static")));

// app.use(express.json());
// app.use(express.static(path.join(__dirname, 'client')))
app.use(morgan("dev"));
//app.use(userRoutes);
//app.use(todoRoutes);

// DUMMY ROUTE
// app.get("/", function(req, res) {
//   res.render("index", {
//     layout: "layout",
//     firstName: "Sundeep",
//     lastName: "Charan Ramkumar",
//     combineNames: function() {
//       return this.firstName + this.lastName;
//     }
//   });
// });

app.get("/index", function(req, res) {
  var queryParams = req.query;
  res.render("index", {
    firstName: queryParams.firstName,
    lastName: queryParams.lastName
    // combineNames: function() {
    //   return this.firstName + " " + this.lastName;
    // }
  });
});

app.get("/todo", function(req, res) {
  res.render("todo", {
    students: [
      {
        userId: 1,
        id: 1,
        title:
          "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body:
          "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      },
      {
        userId: 1,
        id: 2,
        title: "qui est esse",
        body:
          "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
      },
      {
        userId: 1,
        id: 3,
        title: "ea molestias quasi exercitationem repellat qui ipsa sit aut",
        body:
          "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
      },
      {
        userId: 1,
        id: 4,
        title: "eum et est occaecati",
        body:
          "ullam et saepe reiciendis voluptatem adipisci\nsit amet autem assumenda provident rerum culpa\nquis hic commodi nesciunt rem tenetur doloremque ipsam iure\nquis sunt voluptatem rerum illo velit"
      },
      {
        userId: 1,
        id: 5,
        title: "nesciunt quas odio",
        body:
          "repudiandae veniam quaerat sunt sed\nalias aut fugiat sit autem sed est\nvoluptatem omnis possimus esse voluptatibus quis\nest aut tenetur dolor neque"
      },
      {
        userId: 1,
        id: 6,
        title: "dolorem eum magni eos aperiam quia",
        body:
          "ut aspernatur corporis harum nihil quis provident sequi\nmollitia nobis aliquid molestiae\nperspiciatis et ea nemo ab reprehenderit accusantium quas\nvoluptate dolores velit et doloremque molestiae"
      },
      {
        userId: 1,
        id: 7,
        title: "magnam facilis autem",
        body:
          "dolore placeat quibusdam ea quo vitae\nmagni quis enim qui quis quo nemo aut saepe\nquidem repellat excepturi ut quia\nsunt ut sequi eos ea sed quas"
      },
      {
        userId: 1,
        id: 8,
        title: "dolorem dolore est ipsam",
        body:
          "dignissimos aperiam dolorem qui eum\nfacilis quibusdam animi sint suscipit qui sint possimus cum\nquaerat magni maiores excepturi\nipsam ut commodi dolor voluptatum modi aut vitae"
      },
      {
        userId: 1,
        id: 9,
        title: "nesciunt iure omnis dolorem tempora et accusantium",
        body:
          "consectetur animi nesciunt iure dolore\nenim quia ad\nveniam autem ut quam aut nobis\net est aut quod aut provident voluptas autem voluptas"
      },
      {
        userId: 1,
        id: 10,
        title: "optio molestias id quia eum",
        body:
          "quo et expedita modi cum officia vel magni\ndoloribus qui repudiandae\nvero nisi sit\nquos veniam quod sed accusamus veritatis error"
      }
    ]
  });
});

app.get("/contact", function(req, res) {
  res.render("contactus");
});

// app.get("/students", function(req, res) {
//   res.render("students", {
//     students: [{ id: 1 }, { id: 2 }]
//   });
// });

// app.get("/demo", function(req, res) {
//   var num1 = req.params.num1;
//   var num2 = req.params.num2;
//   res.render("sum", {
//     num1: num1,
//     num2: num2,
//     sum: function() {
//       return this.num1 + this.num2;
//     }
//   });
// });

app.listen(5000, function() {
  console.log("port 5000 is started");
});
